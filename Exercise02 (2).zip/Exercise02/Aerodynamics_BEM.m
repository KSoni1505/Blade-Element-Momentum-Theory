% -----------------------------
% Function: Calculates aerodynamic torque and thrust based on the "Blade
% Element Momentum Theory following [3]
% ------------
% Input:
% - x           vector of states 
% - v_0         scalar of rotor-effective wind speed
% - Parameter   struct of Parameters
% ------------
% Output:
% - M_a         scalar of aerodynamic torque
% - F_a         scalar of aerodynamic thrust
% ------------
% Modified: 
% 
% ------------
% Created: 
% Team Number 4 on 14-June-2024
% ----------------------------------
function [M_a, F_a] = Aerodynamics_BEM(x, v_0, Parameter)
    Omega = x(1); 
    z = 3;           % number of wind turbine blades
    rho = Parameter.General.rho; 
    x_T_dot = x(3);
    v_rel = v_0 - x_T_dot;
    v_0 = v_rel;
    
    % BEM imports AeroDyn data for calculations
    BEM = ReadAirfoils("WindStep_08_AeroFile.dat");
    
    % Calculation of constants for a and ap
    n_elements = BEM.BldNodes;  % Number of blade elements
    Sigma = z * BEM.Chord ./ (2 * pi * BEM.RNodes);
    lambda_r = Omega * BEM.RNodes / v_0;
    
    Thrust_in_points = zeros(1, n_elements);
    Moment_in_points = zeros(1, n_elements);

    % Iterate through each blade element
    for i = 1:n_elements
        r = BEM.RNodes(i); 
        TA = BEM.AeroTwst(i);  % angle of twist for each airfoil
    
        a = 0.6;  % First guess for axial induction factor
        ap = 0;   % first guess for tangential induction factor  

        % Iterate to find axial and tangential induction factors
        for iter = 1:30
            phi = atan((1 - a) * v_0 / ((1 + ap) * Omega * r));  % Angle of relative flow  
            AOA = phi * 180 / pi - TA;  % Angle of Attack
            N_airfoil = BEM.NFoil(i);  % Number of Airfoils
            L_airfoil = BEM.DRNodes(i);  % length of airfoil for each node

            % Compute Cl and Cd directly from the BEM 
            Cl = interp1(BEM.AoA{N_airfoil}, BEM.Cl{N_airfoil}, AOA, 'linear', 'extrap');
            Cd = interp1(BEM.AoA{N_airfoil}, BEM.Cd{N_airfoil}, AOA, 'linear', 'extrap');
    
            % Calculation of axial and tangential induction factor
            Sigma_i = Sigma(i);
            lambda_r_i = lambda_r(i);
    
            eq1 = @(a_new) a_new / (1 - a_new) - (Sigma_i * Cl * cos(phi)) / (4 * sin(phi)^2);
            eq2 = @(ap_new, a_new) ap_new / (1 - a_new) - (Sigma_i * Cl) / (4 * lambda_r_i * sin(phi));
    
            a_new = fzero(eq1, a);
            ap_new = fzero(@(ap_new) eq2(ap_new, a_new), ap);
    
            % Check for convergence     
            if abs(a_new - a) < 1e-2 && abs(ap_new - ap) < 1e-2
                break;
            end
    
            a = a_new;
            ap = ap_new;
        end
    
        % Thrust force and moment calculation for each airfoil
        Thrust_in_points(i) = Sigma_i * pi * rho * v_0^2 * (1 - a)^2 * (Cl * cos(phi) + Cd * sin(phi)) * r * L_airfoil / sin(phi)^2;
        Moment_in_points(i) = Sigma_i * pi * rho * v_0^2 * (1 - a)^2 * (Cl * sin(phi) - Cd * cos(phi)) * r^2 * L_airfoil / sin(phi)^2;
    end
    
    % Total of Thrust force and moment
    F_a = sum(Thrust_in_points);
    M_a = sum(Moment_in_points);
end

