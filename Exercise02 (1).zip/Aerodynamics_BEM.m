% -----------------------------
% Function: Calculates aerodynamic torque and thrust based on the "Blade
% Element Momentum Theory following [3]
% ------------
% Input:
% - x           vector of states 
% - v_0         scalar of rotor-effective wind speed
% - Parameter   struct of Parameters
% ------------
% Output:
% - M_a         scalar of aerodynamic torque
% - F_a         scalar of aerodynamic thrust
% ------------
% Modified: 
% - <Name> on <date>
% ------------
% Created: 
% <Name> on <date>
% ----------------------------------
function [M_a,F_a] = Aerodynamics_BEM(x,v_0,Parameter)

% Dummy values
M_a         = NaN; 
F_a         = NaN;

end